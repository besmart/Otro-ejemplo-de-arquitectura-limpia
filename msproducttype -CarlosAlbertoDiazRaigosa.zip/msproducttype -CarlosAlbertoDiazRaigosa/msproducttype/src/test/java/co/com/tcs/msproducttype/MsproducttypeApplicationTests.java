package co.com.tcs.msproducttype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsproducttypeApplicationTests {

	@Test
	void contextLoads() {
	}

}
