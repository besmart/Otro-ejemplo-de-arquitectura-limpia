package co.com.tcs.msproducttype.model.repository;

import co.com.tcs.msproducttype.api.contracts.ProductTypeResponse;
import co.com.tcs.msproducttype.model.ProductType;

import java.util.List;

public interface  ProductTypeRepository {
    public ProductType getById(String type);
    public List<ProductType>  getAll();
    // public ProductType create(ProductType productType);
    public ProductTypeResponse create(ProductType productType);
    public ProductTypeResponse update(ProductType productType);
    public ProductType delete(String type);

}
