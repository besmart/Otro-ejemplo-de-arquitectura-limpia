package co.com.tcs.msproducttype.api;

import co.com.tcs.msproducttype.api.contracts.ProductTypeResponse;
import co.com.tcs.msproducttype.model.ProductType;
import co.com.tcs.msproducttype.usecase.ProductTypeUseCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/msproducttype", produces = MediaType.APPLICATION_JSON_VALUE)
public class ApiRest {

    @Autowired
    private ProductTypeUseCase productTypeUseCase;

    @GetMapping("/getById")
    public ResponseEntity<ProductTypeResponse> getById(@RequestParam String type) {
        return productTypeUseCase.getById(type);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<ProductType>> getAll() {
        return productTypeUseCase.queryAllProductType();
    }

    @PostMapping("/create")
    public ResponseEntity<ProductTypeResponse> createProductType(@RequestBody ProductType productType) {
        return productTypeUseCase.create(productType);
    }

    @PostMapping("/update")
    public ResponseEntity<ProductTypeResponse> updateProductType(@RequestBody ProductType productType) {
        return productTypeUseCase.update(productType);
    }

    @GetMapping("/delete")
    public ResponseEntity<ProductTypeResponse> delete(@RequestParam String type) {
        return productTypeUseCase.delete(type);
    }
}
