package co.com.tcs.msproducttype.infraestructure.adapters.adapter;

import co.com.tcs.msproducttype.api.contracts.ProductTypeResponse;
import co.com.tcs.msproducttype.infraestructure.adapters.JpaProductTypeAdapter;
import co.com.tcs.msproducttype.model.ProductType;
import co.com.tcs.msproducttype.model.repository.ProductTypeRepository;
import lombok.Builder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
@Builder
@Component
public class ProductTypeAdapter implements ProductTypeRepository {
    @Autowired
    private JpaProductTypeAdapter jpaProductTypeAdapter;
    @Override
    public ProductType getById(String type) {
        var productType = jpaProductTypeAdapter.findById(type);
        var response = ProductTypeResponse.builder().build();
        var exist = jpaProductTypeAdapter.existsById(type);
        var valida = ProductType.builder().build();
        if (!exist) {
            response.setErrorCode(3);
            response.setErrorDescription("Not ProductType info");
        } else if (productType.get().getType() != null) {
            valida.setType(productType.get().getType());
            valida.setTitle(productType.get().getTitle());
            valida.setDescription(productType.get().getDescription());
            valida.setStatus(productType.get().getStatus());
            valida.setUserCreation(productType.get().getUserCreation());
            valida.setDateCreation(productType.get().getDateCreation());
        }
        return valida;
    }

    @Override
    public List<ProductType> getAll() {
        var data = jpaProductTypeAdapter.findAll();
        List<ProductType> response = new ArrayList<>();

        data.forEach(ProductTypeEntity -> {
            var dataProductType = ProductType.builder().build();
            dataProductType.setType(ProductTypeEntity.getType());
            dataProductType.setDescription(ProductTypeEntity.getDescription());
            dataProductType.setTitle(ProductTypeEntity.getTitle());
            dataProductType.setStatus(ProductTypeEntity.getStatus());
            dataProductType.setUserCreation(ProductTypeEntity.getUserCreation());
            dataProductType.setDateCreation(ProductTypeEntity.getDateCreation());
            response.add(dataProductType);
        });
        return response;
    }

    @Override
    public ProductTypeResponse create(ProductType productType) {
        var result = ProductTypeResponse.builder().build();
        var exist = jpaProductTypeAdapter.findById(productType.getType());
        if (!exist.isEmpty()) {
            result.setErrorCode(6);
            result.setErrorDescription("EXISTING RECORD");
        }
        var data = ProductTypeEntity.builder()
                .type(productType.getType())
                .title(productType.getTitle())
                .description(productType.getDescription())
                .status(productType.getStatus())
                .dateCreation(productType.getDateCreation())
                .userCreation(productType.getUserCreation())
                .build();
        if (exist.isEmpty()) {
            result.setErrorCode(0);
            var response = jpaProductTypeAdapter.save(data);
        }
        if (result == null) {
            result.setErrorCode(5);
            result.setErrorDescription("NOT CREATE");
        }
        return result;
    }

    @Override
    public ProductTypeResponse update(ProductType productType) {
        var result = ProductTypeResponse.builder().build();
        var exist = jpaProductTypeAdapter.findById(productType.getType());
        if (exist.isEmpty()) {
            result.setErrorCode(7);
            result.setErrorDescription("NO RECORD TO UPDATE");
        }
        var data = ProductTypeEntity.builder()
                .type(productType.getType())
                .title(productType.getTitle())
                .description(productType.getDescription())
                .status(productType.getStatus())
                .dateCreation(productType.getDateCreation())
                .userCreation(productType.getUserCreation())
                .build();
        if (!exist.isEmpty()) {
            result.setErrorCode(0);
            var response = jpaProductTypeAdapter.save(data);
            result.setErrorDescription("UPDATED RECORD");
        }
        if (result == null) {
            result.setErrorCode(5);
            result.setErrorDescription("NOT CREATE");
        }
        return result;
    }

    @Override
    public ProductType delete(String type) {
        var productType = jpaProductTypeAdapter.findById(type);
        var response = ProductTypeResponse.builder().build();
        var exist = jpaProductTypeAdapter.existsById(type);
        var valida = ProductType.builder().build();
        if (!exist) {
            response.setErrorCode(3);
            response.setErrorDescription("Not ProductType info");
        } else {
            var data = ProductTypeEntity.builder()
                    .type(productType.get().getType())
                    .title(productType.get().getTitle())
                    .description(productType.get().getDescription())
                    .status(productType.get().getStatus())
                    .dateCreation(productType.get().getDateCreation())
                    .userCreation(productType.get().getUserCreation())
                    .build();
                    response.setErrorCode(0);
                    response.setErrorDescription("RECORD DELETED");
                    jpaProductTypeAdapter.deleteById(type);
        }
        return valida;
    }
}
