package co.com.tcs.msproducttype.config;

import co.com.tcs.msproducttype.model.repository.ProductTypeRepository;
import co.com.tcs.msproducttype.usecase.ProductTypeUseCase;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
    @Bean
    ProductTypeUseCase productTypeUseCase(ProductTypeRepository productTypeRepository) {
        return new ProductTypeUseCase(productTypeRepository);
    }
}
