package co.com.tcs.msproducttype.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
 public class ProductType {
    private String type;
    private String title;
    private String description;
    private Boolean status;
    private String dateCreation;
    private String userCreation;
}
