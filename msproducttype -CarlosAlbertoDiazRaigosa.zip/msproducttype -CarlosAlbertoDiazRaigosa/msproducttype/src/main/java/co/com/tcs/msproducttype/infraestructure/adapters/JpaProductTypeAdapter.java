package co.com.tcs.msproducttype.infraestructure.adapters;

import co.com.tcs.msproducttype.infraestructure.adapters.adapter.ProductTypeEntity;
import org.springframework.data.repository.CrudRepository;

public interface JpaProductTypeAdapter extends CrudRepository<ProductTypeEntity, String> {
}
