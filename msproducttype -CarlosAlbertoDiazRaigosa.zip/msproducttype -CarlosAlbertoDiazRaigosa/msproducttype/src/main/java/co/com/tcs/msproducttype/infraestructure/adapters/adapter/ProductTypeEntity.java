package co.com.tcs.msproducttype.infraestructure.adapters.adapter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name= "tbl_product_type")
public class ProductTypeEntity {
    @Id
    private String type;
    @Column
    private String title;
    @Column
    private String description;
    @Column
    private Boolean status;
    @Column(name="date_creation")
    private String dateCreation;
    @Column(name="user_creation")
    private String userCreation;
}
