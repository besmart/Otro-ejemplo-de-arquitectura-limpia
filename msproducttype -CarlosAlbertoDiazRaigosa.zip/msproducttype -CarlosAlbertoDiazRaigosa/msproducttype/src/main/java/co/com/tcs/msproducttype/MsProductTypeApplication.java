package co.com.tcs.msproducttype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsProductTypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsProductTypeApplication.class, args);
	}

}
