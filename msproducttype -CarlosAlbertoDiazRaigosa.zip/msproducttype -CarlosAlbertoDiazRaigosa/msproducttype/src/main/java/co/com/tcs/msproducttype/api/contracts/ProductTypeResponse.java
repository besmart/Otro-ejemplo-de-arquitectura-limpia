package co.com.tcs.msproducttype.api.contracts;

import co.com.tcs.msproducttype.model.ProductType;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ProductTypeResponse {
    private ProductType productType;
    private int errorCode;
    private String errorDescription;
}
