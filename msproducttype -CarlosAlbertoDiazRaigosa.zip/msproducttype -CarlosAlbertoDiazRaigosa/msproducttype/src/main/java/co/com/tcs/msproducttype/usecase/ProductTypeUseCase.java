package co.com.tcs.msproducttype.usecase;

import co.com.tcs.msproducttype.api.contracts.ProductTypeResponse;
import co.com.tcs.msproducttype.model.ProductType;
import co.com.tcs.msproducttype.model.repository.ProductTypeRepository;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@Builder
@AllArgsConstructor
public class ProductTypeUseCase {
    private ProductTypeRepository productTypeRepository;
    public ResponseEntity<ProductTypeResponse> getById(String type){
        var codHttp = HttpStatus.OK;
        var response =
                ProductTypeResponse.builder()
                        .errorCode(0)
                        .errorDescription("Successfully")
                        .build();
        var productType = ProductType.builder()
                                .build();
        var valida = ProductTypeResponse.builder().build();
        if (type == null) {
            response.setErrorCode(1);
            codHttp = HttpStatus.BAD_REQUEST;
            response.setErrorDescription("Type is null");
        } else if (type.equalsIgnoreCase("")) {
            response.setErrorCode(2);
            codHttp = HttpStatus.BAD_REQUEST;
            response.setErrorDescription("Type no data");
        }  else {
                productType = productTypeRepository.getById(type);
                if (productType.getType() == null) {
                    response.setErrorCode(response.getErrorCode());
                    codHttp = HttpStatus.NO_CONTENT;
                    response.setErrorDescription(response.getErrorDescription());
                }
        }
        response.setProductType(productType);
        return new ResponseEntity<ProductTypeResponse>(response,codHttp);
    }

    public ResponseEntity<List<ProductType>> queryAllProductType() {
        var codeHttp = HttpStatus.OK;
        var response = productTypeRepository.getAll();
        return new ResponseEntity<List<ProductType>> (response, codeHttp);
    }

    public ResponseEntity<ProductTypeResponse> create(ProductType productType) {
        // 1. Validate data
        // 2. Validate existe record
        var codeHttp = HttpStatus.OK;
        var response = productTypeRepository.create(productType);
        response.setProductType(productType);
        if (response.getErrorCode()>0) {
            response.setErrorCode(response.getErrorCode());
            response.setErrorDescription(response.getErrorDescription());
            codeHttp = HttpStatus.NOT_FOUND;
        } else {
            if (response.getErrorDescription() == null) {
                response.setErrorDescription("Create Successfully");
            }
            response.setProductType(productType);
        }
        return new ResponseEntity<ProductTypeResponse>(response, codeHttp);
    }

    public ResponseEntity<ProductTypeResponse> update(ProductType productType) {
        // 1. Validate data
        // 2. Validate existe record
        var codeHttp = HttpStatus.OK;
        var response = productTypeRepository.update(productType);
        response.setProductType(productType);
        if (response.getErrorCode()>0) {
            response.setErrorCode(response.getErrorCode());
            response.setErrorDescription(response.getErrorDescription());
            codeHttp = HttpStatus.NOT_FOUND;
        } else {
            if (response.getErrorCode() == 0) {
                response.setErrorCode(response.getErrorCode());
                response.setErrorDescription(response.getErrorDescription());
                codeHttp = HttpStatus.OK;
            }
            response.setProductType(productType);
        }
        return new ResponseEntity<ProductTypeResponse>(response, codeHttp);
    }

    public ResponseEntity<ProductTypeResponse> delete(String type){
        var codHttp = HttpStatus.OK;
        var response =
                ProductTypeResponse.builder()
                        .errorCode(0)
                        .errorDescription("RECORD DELETED SUCCESSFULLY")
                        .build();
        var productType = ProductType.builder()
                .build();
        var valida = ProductTypeResponse.builder().build();
        if (type == null) {
            response.setErrorCode(1);
            codHttp = HttpStatus.BAD_REQUEST;
            response.setErrorDescription("Type is null");
        } else if (type.equalsIgnoreCase("")) {
            response.setErrorCode(2);
            codHttp = HttpStatus.BAD_REQUEST;
            response.setErrorDescription("Type no data");
        }  else {
            productType = productTypeRepository.delete(type);
            if (response.getErrorCode() == 0) {
                response.setErrorCode(response.getErrorCode());
                response.setErrorDescription(response.getErrorDescription());
            }
        }
        response.setProductType(productType);
        return new ResponseEntity<ProductTypeResponse>(response,codHttp);
    }
}
